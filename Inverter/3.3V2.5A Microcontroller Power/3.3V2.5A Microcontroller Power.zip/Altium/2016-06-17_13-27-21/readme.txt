


**********************************************************
*************  Important Instructions Follow  ************
**********************************************************

All files exported to: Z:\\17\\70\\1770687\\26\Altium\2016-06-17_13-27-21\2016-06-17_13-27-21


**********************************************************
***************** Schematic Instructions  ****************
**********************************************************

To import your new Schematic into Altium:

1. Unzip the downloaded folder files to a local directory and
Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".schdoc"
and "Open" the file.
4. Your Schematic should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html



**********************************************************
*******************  PCB Instructions  *******************
**********************************************************


To import your new BOARD into Altium:

1. Unzip the downloaded folder files to a local directory
	and Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".pcbdoc"
and "Open" the file.
4. Planes will need to be repoured to update the Copper Pour Polygons
	a. Once your board is loaded, select the Tools menu from the
	   top Menu Bar
	b. Scroll to the Polygon Pours item on the Tools Menu.
	c. The Polygon Pours item should expand to show more options
	d. Select Repour All Polygons, this will repour all of the
	   polygons.
5. Your board should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new LIBRARY PARTS into Altium follow these steps:

1. After running the Ultra Librarian export for the first time,
you will need to copy the following files into an area where
they can be accessed for all future translations.  They are script
files that Altium will need to be able to find.
	a. UL_Form.dfm
	b. UL_Form.pas
	c. UL_Import.pas
	d. UL_Import.prjScr
2. The above script file will need to be run from within Altium.
This can be done by going to File, Open and selecting the
UL_Import.PrjScr file stored above.
3. Select the "DXP" dropdown menu in the top-left corner runfrom
the drop down menu and select "Run Script". Select "UL_Form.pas"
and click "OK"
4. When the script is run, it will ask you for the file name of the
Ultra Librarian file to run. Click "File...", select the latest file
produced with a date code (for instance 2010-02-17_23-12-34.txt), and
click "Start Import".
5. The script will open a new Integraged Library project and import
the Ultra Librarian data into it.  When complete a message box
will pop up saying that import is done.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_import.html

For a video tutorial, please visit:
http://youtu.be/pih50yx9HYU

**********************************************************
**********************************************************
**********************************************************


Symbol "WB_STARTUP_VOLTAGE_SOURCE" renamed to "WB_STARTUP_VOLTA"
Symbol "WB_SOURCE_RESISTOR" renamed to "WB_SOURCE_RESIST"
Symbol "WB_PRIM_STARTUP_VOLTAGE_SOURCE" renamed to "WB_PRIM_STARTUP_"
Symbol "WB_PRIM_DC_VOLTAGE_SOURCE" renamed to "WB_PRIM_DC_VOLTA"
Symbol "WB_PWL_CURRENT_LOAD" renamed to "WB_PWL_CURRENT_L"
Symbol "WB_ZERO_VOLT_SOURCE" renamed to "WB_ZERO_VOLT_SOU"
Symbol "WB_PWL_VOLTAGE_SOURCE" renamed to "WB_PWL_VOLTAGE_S"
Symbol "WB_PRIM_PWL_VOLTAGE_SOURCE" renamed to "WB_PRIM_PWL_VOLT"
Symbol "WB_PRIMITIVE_BATTERY" renamed to "WB_PRIMITIVE_BAT"
Symbol "WB_TPS54329_EN_WIRE" renamed to "WB_TPS54329_EN_W"
Component "C0805C100M4GACTU" renamed to "C0805C100M4GACTU"
Component "GRM155R61A104KA01D" renamed to "GRM155R61A104KA0"
Component "WB_CONTINUATION" renamed to "WB_CONTINUATION"
Component "C3216JB1A476M" renamed to "C3216JB1A476M"
Component "GRM188R61A105KA61D" renamed to "GRM188R61A105KA6"
Component "GRM033R61A822KA01D" renamed to "GRM033R61A822KA0"
Component "WB_GND" renamed to "WB_GND"
Component "CLF7045T-3R3N" renamed to "CLF7045T-3R3N"
Component "CRCW040210K0FKED" renamed to "CRCW040210K0FKED"
Component "CRCW040225K5FKED" renamed to "CRCW040225K5FKED"
Component "CRCW040284K5FKED" renamed to "CRCW040284K5FKED"
Component "TPS54339DDAR" renamed to "TPS54339DDAR"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "GRM155R60J225ME15D" renamed to "GRM155R60J225ME1"
Component "SLC7649S-101KLB" renamed to "SLC7649S-101KLB"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
Component "GRM32ER7YA106KA12L" renamed to "GRM32ER7YA106KA1"
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_DC_VOLTA was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_DC_VOLTA was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_DC_VOLTA was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Value attribute, a value was created for the symbol.
The Symbol WB_ZERO_VOLT_SOU was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_ZERO_VOLT_SOU was missing a Type attribute, a type was created for the symbol.
The Symbol WB_ZERO_VOLT_SOU was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CFF_BLOCK was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CFF_BLOCK was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CFF_BLOCK was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54339 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54339 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54339 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54329_EN_W was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54329_EN_W was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54329_EN_W was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54329_VEN was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54329_VEN was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54329_VEN was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.44 Process Report


Message - Pattern "SLC7649", entity (115-Line) is a LINE with matching start and end points.
Message - Pattern "SLC7649", entity (117-Line) is a LINE with matching start and end points.
Message - Pattern "SLC7649", entity (119-Line) is a LINE with matching start and end points.
Message - Pattern "SLC7649", entity (121-Line) is a LINE with matching start and end points.
Message - Component "C0805C100M4GACTU" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C100M4GACTU" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C100M4GACTU" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C100M4GACTU" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C100M4GACTU" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A104KA0" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A104KA0" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A104KA0" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A104KA0" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216JB1A476M" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216JB1A476M" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216JB1A476M" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216JB1A476M" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216JB1A476M" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R61A105KA6" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R61A105KA6" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R61A105KA6" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R61A105KA6" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R61A822KA0" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R61A822KA0" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R61A822KA0" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R61A822KA0" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CLF7045T-3R3N" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CLF7045T-3R3N" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CLF7045T-3R3N" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CLF7045T-3R3N" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040210K0FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040210K0FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040210K0FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040225K5FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040225K5FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040225K5FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040284K5FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040284K5FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040284K5FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54339DDAR" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54339DDAR" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54339DDAR" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54339DDAR" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54339DDAR" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54339DDAR" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R60J225ME1" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R60J225ME1" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R60J225ME1" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R60J225ME1" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R60J225ME1" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SLC7649S-101KLB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SLC7649S-101KLB" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SLC7649S-101KLB" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SLC7649S-101KLB" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM32ER7YA106KA1" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM32ER7YA106KA1" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM32ER7YA106KA1" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM32ER7YA106KA1" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   10
Pattern count:    9
Symbol count:     25
Component count:  17

Export

Footprint "0805" has no layer data mapped and will be skipped.
Component "C0805C100M4GACTU" requires footprint "0805" and will be skipped.
Footprint "0402" has no layer data mapped and will be skipped.
Component "GRM155R61A104KA0" requires footprint "0402" and will be skipped.
Component "CRCW040210K0FKED" requires footprint "0402" and will be skipped.
Component "CRCW040225K5FKED" requires footprint "0402" and will be skipped.
Component "CRCW040284K5FKED" requires footprint "0402" and will be skipped.
Component "GRM155R60J225ME1" requires footprint "0402" and will be skipped.
Footprint "0603" has no layer data mapped and will be skipped.
Component "GRM188R61A105KA6" requires footprint "0603" and will be skipped.
Footprint "0201" has no layer data mapped and will be skipped.
Component "GRM033R61A822KA0" requires footprint "0201" and will be skipped.
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "L" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DCR" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "IDC" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "TPS54339DDAR" attribute "TOL" references missing text style ""
Warning: Symbol "TPS54339DDAR" attribute "VAL" references missing text style ""
Warning: Symbol "TPS54339DDAR" attribute "DEV" references missing text style ""
Warning: Symbol "TPS54339DDAR" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "L" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DCR" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "IDC" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
